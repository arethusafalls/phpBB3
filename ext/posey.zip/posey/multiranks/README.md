# phpBB 3.1 Extension - Multi Ranks

## Description
Allows you to give a user upto three special ranks!

## Installation

Clone into phpBB/ext/posey/multiranks:

    git clone https://github.com/MrGoldy/multiranks.git phpBB/ext/posey/multiranks
	
Or download the zip and upload contents to phpBB/ext/posey/multiranks/

Go to "ACP" > "Customise" > "Extensions" and enable the "Multi Ranks" extension.

## License

[GPLv2](license.txt)
